#!/bin/bash

PYTHONPATH=../..
for i in `seq 10`; do ../../osmef.py -s local42 -d; done
for i in `seq 10`; do ../../osmef.py -s local43 -d; done
for i in `seq 10`; do ../../osmef.py -s local44 -d; done
for i in `seq 10`; do ../../osmef.py -s local45 -d; done
for i in `seq 10`; do ../../osmef.py -s local46 -d; done
for i in `seq 10`; do ../../osmef.py -s local47 -d; done
for i in `seq 10`; do ../../osmef.py -s local48 -d; done
for i in `seq 10`; do ../../osmef.py -s local49 -d; done
for i in `seq 10`; do ../../osmef.py -s local50 -d; done
