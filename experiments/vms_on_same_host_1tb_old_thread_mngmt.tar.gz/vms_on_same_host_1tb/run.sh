#!/bin/bash

PYTHONPATH=../..
for i in `seq 10`; do ../../osmef.py -s local34_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local35_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local36_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local37_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local38_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local39_1tb -d; done
for i in `seq 10`; do ../../osmef.py -s local40_1tb -d; done
